import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { checkPasswords } from '../validators/checkPassword';

@Component({
  selector: 'app-reg-list',
  templateUrl: './reg-list.component.html',
  styleUrls: ['./reg-list.component.css']
})
export class RegListComponent implements OnInit {
  form: FormGroup = new FormGroup(
    {
      email: new FormControl('', [Validators.email, Validators.required]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
      confirmPassword: new FormControl(''),
    }, 
    { 
      validators: [checkPasswords] 
    });
  constructor() { }

  ngOnInit(): void {
  }

}
